<?php
/**
 * Plugin Name:       Whatching – Cart Recovery on WhatsApp for WooCommerce
 * Plugin URI:        https://www.whatching.com
 * Description:       Sends WhatsApp reminders, through your Whatching account, to shoppers who leave checkout, with a link that brings back their cart.
 * Version:           1.0.1
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Whatching
 * Author URI:        https://www.whatching.com
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       whatching-cart-recovery
 * Requires Plugins:  woocommerce
 * WC requires at least: 7.2
 * WC tested up to:   10.8
 */

defined( 'ABSPATH' ) || exit;

define( 'WHATCHING_CR_VERSION', '1.0.1' );
define( 'WHATCHING_CR_FILE', __FILE__ );
if ( ! defined( 'WHATCHING_API_BASE' ) ) {
	// Can be overridden in wp-config.php for testing.
	define( 'WHATCHING_API_BASE', 'https://api.whatching.com' );
}

require_once __DIR__ . '/includes/class-whatching-api.php';
require_once __DIR__ . '/includes/class-whatching-capture.php';
require_once __DIR__ . '/includes/class-whatching-admin.php';

// Works with High-Performance Order Storage and the Cart and Checkout blocks.
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WHATCHING_CR_FILE, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', WHATCHING_CR_FILE, true );
		}
	}
);

add_action(
	'plugins_loaded',
	function () {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		Whatching_Api::init();
		Whatching_Capture::init();
		Whatching_Admin::init();
	}
);

// Stop the background check-in when the plugin is turned off.
register_deactivation_hook(
	__FILE__,
	function () {
		Whatching_Api::stop_checkin();
	}
);
