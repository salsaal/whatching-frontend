/* Whatching cart recovery: tells Whatching about the checkout once a phone is entered (classic checkout). */
( function ( $ ) {
	if ( ! window.whatchingCr ) {
		return;
	}
	var timer = null;
	function send() {
		var phone = $( '#billing_phone' ).val() || $( '#shipping_phone' ).val() || '';
		if ( String( phone ).replace( /\D+/g, '' ).length < 8 ) {
			return;
		}
		$.post( window.whatchingCr.ajaxUrl, {
			action: 'whatching_cr_capture',
			nonce: window.whatchingCr.nonce,
			phone: phone,
			first_name: $( '#billing_first_name' ).val() || '',
			country: $( '#billing_country' ).val() || $( '#shipping_country' ).val() || ''
		} );
	}
	$( document.body ).on( 'change blur', '#billing_phone, #shipping_phone, #billing_first_name, #billing_country', function () {
		clearTimeout( timer );
		timer = setTimeout( send, 800 );
	} );
} )( jQuery );
