<?php
/**
 * Notices a shopper's checkout once a phone is entered (only while the
 * merchant has cart reminders on in Whatching), restores the cart from the
 * reminder link, and reports the order when it's placed.
 *
 * The cart's products stay here in WordPress (a transient kept 7 days);
 * Whatching only receives the phone, first name, item names and quantities,
 * the total and a random token.
 */

defined( 'ABSPATH' ) || exit;

class Whatching_Capture {
	const SESSION_TOKEN = 'whatching_cr_token';
	const SESSION_LAST  = 'whatching_cr_last';
	const QUERY_ARG     = 'whatching_cart';
	const TRANSIENT     = 'whatching_cr_cart_';
	const KEEP_SECONDS  = 7 * DAY_IN_SECONDS;

	public static function init() {
		// Checkout block (Store API). WooCommerce 7.2+.
		add_action( 'woocommerce_store_api_cart_update_customer_from_request', array( __CLASS__, 'from_customer_request' ), 20, 2 );
		// WooCommerce 10.8+: "for abandoned-cart trackers", no draft order exists yet.
		add_action( 'woocommerce_store_api_checkout_update_draft', array( __CLASS__, 'from_draft_update' ), 20, 1 );

		// Classic checkout: a small script reports the phone when it changes.
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_classic_script' ) );
		add_action( 'wp_ajax_whatching_cr_capture', array( __CLASS__, 'ajax_capture' ) );
		add_action( 'wp_ajax_nopriv_whatching_cr_capture', array( __CLASS__, 'ajax_capture' ) );

		// Orders: classic and block checkout.
		add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'classic_order_processed' ), 20, 3 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( __CLASS__, 'order_processed' ), 20, 1 );

		// The reminder link.
		add_action( 'wp_loaded', array( __CLASS__, 'maybe_restore_cart' ), 20 );

		// Background sends, so checkout never waits for Whatching.
		add_action( 'whatching_cr_send_cart', array( __CLASS__, 'send_cart' ), 10, 1 );
		add_action( 'whatching_cr_send_converted', array( __CLASS__, 'send_converted' ), 10, 1 );
	}

	public static function from_customer_request( $customer, $request ) {
		if ( $customer instanceof WC_Customer ) {
			self::capture( self::phone_of( $customer ), $customer->get_billing_first_name(), self::country_of( $customer ) );
		}
	}

	public static function from_draft_update( $request ) {
		$customer = WC()->customer;
		if ( $customer instanceof WC_Customer ) {
			self::capture( self::phone_of( $customer ), $customer->get_billing_first_name(), self::country_of( $customer ) );
		}
	}

	private static function phone_of( WC_Customer $customer ) {
		$phone = $customer->get_billing_phone();
		return $phone ? $phone : $customer->get_shipping_phone();
	}

	private static function country_of( WC_Customer $customer ) {
		$country = $customer->get_billing_country();
		return $country ? $country : $customer->get_shipping_country();
	}

	public static function enqueue_classic_script() {
		if ( ! Whatching_Api::reminders_on() || ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() ) {
			return;
		}
		if ( function_exists( 'has_block' ) && has_block( 'woocommerce/checkout' ) ) {
			return; // The block checkout is handled through the Store API hooks.
		}
		wp_enqueue_script(
			'whatching-cr-checkout',
			plugins_url( 'assets/checkout.js', WHATCHING_CR_FILE ),
			array( 'jquery' ),
			WHATCHING_CR_VERSION,
			true
		);
		wp_localize_script(
			'whatching-cr-checkout',
			'whatchingCr',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'whatching_cr_capture' ),
			)
		);
	}

	public static function ajax_capture() {
		check_ajax_referer( 'whatching_cr_capture', 'nonce' );
		$phone      = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		$first_name = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
		$country    = isset( $_POST['country'] ) ? sanitize_text_field( wp_unslash( $_POST['country'] ) ) : '';
		self::capture( $phone, $first_name, $country );
		wp_send_json_success();
	}

	/**
	 * Records the current cart for reminders.
	 */
	private static function capture( $phone, $first_name, $country ) {
		if ( ! Whatching_Api::reminders_on() || ! WC()->cart || WC()->cart->is_empty() || ! WC()->session ) {
			return;
		}
		$phone = trim( (string) $phone );
		if ( strlen( preg_replace( '/\D+/', '', $phone ) ) < 8 ) {
			return;
		}

		$token = WC()->session->get( self::SESSION_TOKEN );
		if ( ! is_string( $token ) || ! preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ) {
			$token = wp_generate_password( 32, false, false );
			WC()->session->set( self::SESSION_TOKEN, $token );
		}

		$snapshot = array();
		$items    = array();
		foreach ( WC()->cart->get_cart() as $line ) {
			$product = isset( $line['data'] ) ? $line['data'] : null;
			if ( ! $product instanceof WC_Product ) {
				continue;
			}
			$snapshot[] = array(
				'product_id'   => (int) $line['product_id'],
				'variation_id' => (int) $line['variation_id'],
				'quantity'     => (int) $line['quantity'],
				'variation'    => isset( $line['variation'] ) && is_array( $line['variation'] ) ? $line['variation'] : array(),
			);
			$items[]    = array(
				'name'     => wp_strip_all_tags( $product->get_name() ),
				'quantity' => (int) $line['quantity'],
			);
		}
		if ( ! $items ) {
			return;
		}
		set_transient( self::TRANSIENT . $token, $snapshot, self::KEEP_SECONDS );

		$payload = array(
			'token'     => $token,
			'phone'     => $phone,
			'country'   => strtoupper( substr( (string) $country, 0, 2 ) ),
			'firstName' => $first_name,
			'items'     => $items,
			'total'     => (string) WC()->cart->get_total( 'edit' ),
			'currency'  => get_woocommerce_currency(),
		);

		// Don't resend the same cart more than every 10 minutes.
		$hash = md5( wp_json_encode( $payload ) );
		$last = WC()->session->get( self::SESSION_LAST );
		if ( is_array( $last ) && $last['hash'] === $hash && ( time() - (int) $last['at'] ) < 10 * MINUTE_IN_SECONDS ) {
			return;
		}
		WC()->session->set( self::SESSION_LAST, array( 'hash' => $hash, 'at' => time() ) );
		self::queue( 'whatching_cr_send_cart', $payload );
	}

	public static function classic_order_processed( $order_id, $posted_data, $order ) {
		self::order_processed( $order instanceof WC_Order ? $order : wc_get_order( $order_id ) );
	}

	public static function order_processed( $order ) {
		if ( ! $order instanceof WC_Order || ! WC()->session || ! Whatching_Api::is_connected() ) {
			return;
		}
		$token = WC()->session->get( self::SESSION_TOKEN );
		if ( ! is_string( $token ) || '' === $token ) {
			return;
		}
		self::queue(
			'whatching_cr_send_converted',
			array(
				'token'       => $token,
				'orderId'     => (string) $order->get_id(),
				'orderNumber' => (string) $order->get_order_number(),
				'total'       => (string) $order->get_total(),
			)
		);
		WC()->session->set( self::SESSION_TOKEN, null );
		WC()->session->set( self::SESSION_LAST, null );
		delete_transient( self::TRANSIENT . $token );
	}

	/**
	 * ?whatching_cart=<token> refills the shopper's cart and opens checkout.
	 */
	public static function maybe_restore_cart() {
		if ( empty( $_GET[ self::QUERY_ARG ] ) || is_admin() || wp_doing_ajax() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$token = sanitize_text_field( wp_unslash( $_GET[ self::QUERY_ARG ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! preg_match( '/^[A-Za-z0-9]{32}$/', $token ) || ! WC()->cart ) {
			return;
		}
		$snapshot = get_transient( self::TRANSIENT . $token );
		if ( is_array( $snapshot ) && $snapshot ) {
			WC()->cart->empty_cart();
			foreach ( $snapshot as $line ) {
				WC()->cart->add_to_cart(
					(int) $line['product_id'],
					max( 1, (int) $line['quantity'] ),
					(int) $line['variation_id'],
					is_array( $line['variation'] ) ? $line['variation'] : array()
				);
			}
			if ( WC()->session ) {
				WC()->session->set( self::SESSION_TOKEN, $token );
			}
		}
		wp_safe_redirect( wc_get_checkout_url() );
		exit;
	}

	private static function queue( $hook, $payload ) {
		if ( function_exists( 'WC' ) && WC()->queue() ) {
			WC()->queue()->add( $hook, array( $payload ), 'whatching' );
		} elseif ( 'whatching_cr_send_cart' === $hook ) {
			self::send_cart( $payload );
		} else {
			self::send_converted( $payload );
		}
	}

	public static function send_cart( $payload ) {
		$result = Whatching_Api::signed_post( 'cart', $payload );
		Whatching_Api::refresh();
		if ( ! is_wp_error( $result ) && isset( $result['reason'] ) && 'reminders_off' === $result['reason'] ) {
			update_option( Whatching_Api::OPTION_REMINDERS, 'no', false );
		}
	}

	public static function send_converted( $payload ) {
		Whatching_Api::signed_post( 'converted', $payload );
	}
}
