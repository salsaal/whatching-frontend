<?php
/**
 * WooCommerce → Whatching: connect with a code from the Whatching Store page.
 */

defined( 'ABSPATH' ) || exit;

class Whatching_Admin {
	const PAGE = 'whatching-cart-recovery';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_whatching_cr_connect', array( __CLASS__, 'handle_connect' ) );
		add_action( 'admin_post_whatching_cr_disconnect', array( __CLASS__, 'handle_disconnect' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( WHATCHING_CR_FILE ), array( __CLASS__, 'action_links' ) );
	}

	public static function menu() {
		add_submenu_page(
			'woocommerce',
			__( 'Whatching', 'whatching-cart-recovery' ),
			__( 'Whatching', 'whatching-cart-recovery' ),
			'manage_woocommerce',
			self::PAGE,
			array( __CLASS__, 'render' )
		);
	}

	public static function action_links( $links ) {
		$url = admin_url( 'admin.php?page=' . self::PAGE );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'whatching-cart-recovery' ) . '</a>' );
		return $links;
	}

	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		Whatching_Api::refresh( true );
		$notice = isset( $_GET['whatching_notice'] ) ? sanitize_key( wp_unslash( $_GET['whatching_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$error  = get_transient( 'whatching_cr_error_' . get_current_user_id() );
		delete_transient( 'whatching_cr_error_' . get_current_user_id() );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Whatching Cart Recovery', 'whatching-cart-recovery' ); ?></h1>
			<?php if ( 'connected' === $notice ) : ?>
				<div class="notice notice-success"><p><?php esc_html_e( 'Connected to Whatching.', 'whatching-cart-recovery' ); ?></p></div>
			<?php elseif ( 'disconnected' === $notice ) : ?>
				<div class="notice notice-info"><p><?php esc_html_e( 'Disconnected from Whatching. No shopper details are sent any more.', 'whatching-cart-recovery' ); ?></p></div>
			<?php endif; ?>
			<?php if ( $error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<?php if ( Whatching_Api::is_connected() ) : ?>
				<p>
					<?php
					/* translators: %s: store name in Whatching */
					printf( esc_html__( 'Connected to Whatching as “%s”.', 'whatching-cart-recovery' ), esc_html( (string) get_option( Whatching_Api::OPTION_STORE ) ) );
					?>
				</p>
				<?php if ( Whatching_Api::reminders_on() ) : ?>
					<p><strong><?php esc_html_e( 'Cart reminders are on.', 'whatching-cart-recovery' ); ?></strong> <?php esc_html_e( 'Shoppers who enter a phone number at checkout and leave get WhatsApp reminders with a link back to their cart.', 'whatching-cart-recovery' ); ?></p>
				<?php else : ?>
					<p><?php esc_html_e( 'Cart reminders are off. Turn them on and choose the reminder messages on your Whatching Store page. Until then, nothing about shoppers is sent.', 'whatching-cart-recovery' ); ?></p>
				<?php endif; ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="whatching_cr_disconnect" />
					<?php wp_nonce_field( 'whatching_cr_disconnect' ); ?>
					<?php submit_button( __( 'Disconnect', 'whatching-cart-recovery' ), 'secondary' ); ?>
				</form>
			<?php else : ?>
				<p><?php esc_html_e( 'Connect this store to Whatching to send cart reminders on WhatsApp.', 'whatching-cart-recovery' ); ?></p>
				<ol>
					<li><?php esc_html_e( 'On Whatching, open the Store page and click “Connect plugin”.', 'whatching-cart-recovery' ); ?></li>
					<li><?php esc_html_e( 'Paste the code here and click Connect.', 'whatching-cart-recovery' ); ?></li>
				</ol>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="whatching_cr_connect" />
					<?php wp_nonce_field( 'whatching_cr_connect' ); ?>
					<input type="text" name="whatching_code" class="regular-text" autocomplete="off" placeholder="<?php esc_attr_e( 'Code from Whatching', 'whatching-cart-recovery' ); ?>" required />
					<?php submit_button( __( 'Connect', 'whatching-cart-recovery' ) ); ?>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function handle_connect() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'whatching-cart-recovery' ) );
		}
		check_admin_referer( 'whatching_cr_connect' );
		$code   = isset( $_POST['whatching_code'] ) ? sanitize_text_field( wp_unslash( $_POST['whatching_code'] ) ) : '';
		$result = Whatching_Api::connect( $code );
		if ( is_wp_error( $result ) ) {
			set_transient( 'whatching_cr_error_' . get_current_user_id(), $result->get_error_message(), MINUTE_IN_SECONDS );
			wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE ) );
			exit;
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE . '&whatching_notice=connected' ) );
		exit;
	}

	public static function handle_disconnect() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'whatching-cart-recovery' ) );
		}
		check_admin_referer( 'whatching_cr_disconnect' );
		Whatching_Api::disconnect();
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE . '&whatching_notice=disconnected' ) );
		exit;
	}
}
