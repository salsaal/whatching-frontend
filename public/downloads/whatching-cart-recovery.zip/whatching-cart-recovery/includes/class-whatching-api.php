<?php
/**
 * Talks to Whatching. Nothing is sent until the merchant connects the plugin
 * with a code from their Whatching Store page.
 */

defined( 'ABSPATH' ) || exit;

class Whatching_Api {
	const OPTION_STORE_ID  = 'whatching_cr_store_id';
	const OPTION_SECRET    = 'whatching_cr_secret';
	const OPTION_STORE     = 'whatching_cr_store_name';
	const OPTION_REMINDERS = 'whatching_cr_reminders_on';
	const OPTION_CHECKED   = 'whatching_cr_checked_at';
	const CHECKIN_HOOK     = 'whatching_cr_checkin';
	const CHECKIN_EVERY    = 15 * MINUTE_IN_SECONDS;

	/**
	 * A check-in every 15 minutes in the background (WooCommerce's Action
	 * Scheduler), so the plugin notices when reminders are switched on or off
	 * on Whatching without anyone opening its page.
	 */
	public static function init() {
		add_action( self::CHECKIN_HOOK, array( __CLASS__, 'checkin' ) );
		add_action( 'init', array( __CLASS__, 'ensure_checkin' ), 20 );
	}

	public static function checkin() {
		self::refresh( true );
	}

	public static function ensure_checkin() {
		if ( ! self::is_connected() || ! function_exists( 'as_has_scheduled_action' ) ) {
			return;
		}
		// Look at most once an hour, to keep page loads light.
		if ( get_transient( 'whatching_cr_checkin_ok' ) ) {
			return;
		}
		if ( ! as_has_scheduled_action( self::CHECKIN_HOOK, array(), 'whatching' ) ) {
			as_schedule_recurring_action( time() + MINUTE_IN_SECONDS, self::CHECKIN_EVERY, self::CHECKIN_HOOK, array(), 'whatching' );
		}
		set_transient( 'whatching_cr_checkin_ok', 1, HOUR_IN_SECONDS );
	}

	public static function stop_checkin() {
		delete_transient( 'whatching_cr_checkin_ok' );
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( self::CHECKIN_HOOK, array(), 'whatching' );
		}
	}

	/**
	 * Whatching's API address. Developers can point a test site elsewhere with
	 * the WHATCHING_API_BASE constant or the whatching_cr_api_base filter.
	 */
	public static function base() {
		return untrailingslashit( (string) apply_filters( 'whatching_cr_api_base', WHATCHING_API_BASE ) );
	}

	public static function is_connected() {
		return (bool) get_option( self::OPTION_STORE_ID ) && (bool) get_option( self::OPTION_SECRET );
	}

	public static function reminders_on() {
		return self::is_connected() && 'yes' === get_option( self::OPTION_REMINDERS );
	}

	/**
	 * Swaps the one-time code for this store's secret.
	 *
	 * @param string $code Code from the Whatching Store page.
	 * @return true|WP_Error
	 */
	public static function connect( $code ) {
		$response = wp_remote_post(
			self::base() . '/api/v1/stores/woocommerce/plugin/connect',
			array(
				'timeout' => 15,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode(
					array(
						'code'    => $code,
						'siteUrl' => home_url( '/' ),
						'version' => WHATCHING_CR_VERSION,
					)
				),
			)
		);
		$data = self::decode( $response );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		update_option( self::OPTION_STORE_ID, sanitize_text_field( $data['storeId'] ), false );
		update_option( self::OPTION_SECRET, sanitize_text_field( $data['secret'] ), false );
		update_option( self::OPTION_STORE, sanitize_text_field( $data['storeName'] ), false );
		update_option( self::OPTION_REMINDERS, ! empty( $data['cartRemindersEnabled'] ) ? 'yes' : 'no', false );
		update_option( self::OPTION_CHECKED, time(), false );
		delete_transient( 'whatching_cr_checkin_ok' );
		self::ensure_checkin();
		return true;
	}

	public static function disconnect() {
		self::stop_checkin();
		foreach ( array( self::OPTION_STORE_ID, self::OPTION_SECRET, self::OPTION_STORE, self::OPTION_REMINDERS, self::OPTION_CHECKED ) as $option ) {
			delete_option( $option );
		}
	}

	/**
	 * Refreshes whether reminders are on (at most every 10 minutes unless forced).
	 */
	public static function refresh( $force = false ) {
		if ( ! self::is_connected() ) {
			return;
		}
		if ( ! $force && ( time() - (int) get_option( self::OPTION_CHECKED, 0 ) ) < 10 * MINUTE_IN_SECONDS ) {
			return;
		}
		update_option( self::OPTION_CHECKED, time(), false );
		$data = self::signed_post( 'ping', array( 'version' => WHATCHING_CR_VERSION ) );
		if ( is_wp_error( $data ) ) {
			if ( 401 === (int) $data->get_error_data() ) {
				// Disconnected on Whatching: stop capturing.
				update_option( self::OPTION_REMINDERS, 'no', false );
			}
			return;
		}
		update_option( self::OPTION_REMINDERS, ! empty( $data['cartRemindersEnabled'] ) ? 'yes' : 'no', false );
		if ( ! empty( $data['storeName'] ) ) {
			update_option( self::OPTION_STORE, sanitize_text_field( $data['storeName'] ), false );
		}
	}

	/**
	 * A call signed with this store's secret: HMAC-SHA256 of "timestamp.body".
	 */
	public static function signed_post( $path, $payload ) {
		if ( ! self::is_connected() ) {
			return new WP_Error( 'whatching_not_connected', __( 'Not connected to Whatching.', 'whatching-cart-recovery' ) );
		}
		$body      = wp_json_encode( $payload );
		$timestamp = (string) time();
		$signature = hash_hmac( 'sha256', $timestamp . '.' . $body, (string) get_option( self::OPTION_SECRET ) );
		$response  = wp_remote_post(
			self::base() . '/api/v1/stores/woocommerce/plugin/' . $path,
			array(
				'timeout' => 10,
				'headers' => array(
					'Content-Type'          => 'application/json',
					'X-Whatching-Store'     => (string) get_option( self::OPTION_STORE_ID ),
					'X-Whatching-Timestamp' => $timestamp,
					'X-Whatching-Signature' => $signature,
				),
				'body'    => $body,
			)
		);
		return self::decode( $response );
	}

	private static function decode( $response ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$json = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code < 200 || $code >= 300 ) {
			$message = is_array( $json ) && ! empty( $json['message'] ) ? $json['message'] : __( 'Whatching could not be reached. Please try again.', 'whatching-cart-recovery' );
			return new WP_Error( 'whatching_http', $message, $code );
		}
		return is_array( $json ) && isset( $json['data'] ) ? $json['data'] : array();
	}
}
