<?php
/**
 * Removes everything the plugin stored.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

foreach ( array( 'whatching_cr_store_id', 'whatching_cr_secret', 'whatching_cr_store_name', 'whatching_cr_reminders_on', 'whatching_cr_checked_at' ) as $whatching_option ) {
	delete_option( $whatching_option );
}

delete_transient( 'whatching_cr_checkin_ok' );
if ( function_exists( 'as_unschedule_all_actions' ) ) {
	as_unschedule_all_actions( 'whatching_cr_checkin', array(), 'whatching' );
}

global $wpdb;
// Saved carts (transients) for the reminder links.
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_whatching\\_cr\\_cart\\_%' OR option_name LIKE '\\_transient\\_timeout\\_whatching\\_cr\\_cart\\_%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
