=== Whatching – Cart Recovery on WhatsApp for WooCommerce ===
Contributors: whatching
Tags: whatsapp, abandoned cart, cart recovery, woocommerce, reminders
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Send WhatsApp reminders to shoppers who leave checkout, with a link that brings back their cart. Requires a Whatching account.

== Description ==

Whatching sends WhatsApp messages for your WooCommerce store from your own WhatsApp Business number. This plugin adds **cart recovery**:

* When a shopper enters a phone number at checkout and then leaves, Whatching sends up to three WhatsApp reminders, at times you choose.
* Each reminder has a link that refills the shopper's cart and opens checkout.
* Reminders stop as soon as the shopper orders, replies, or asks to stop.
* Your Whatching Store page shows every reminder and the orders that were recovered.

Order updates and cash-on-delivery confirmations work without this plugin, by connecting your store on Whatching.

= Before you turn reminders on =

Cart reminders are marketing messages. You are responsible for collecting your customers' consent to receive WhatsApp marketing messages, as required by WhatsApp's policies and the laws that apply to your store. WhatsApp (Meta) charges its marketing rate for each reminder delivered; Meta bills you directly.

= External service =

This plugin connects to Whatching (https://www.whatching.com), a third-party service, to send the WhatsApp reminders. Nothing is sent until you connect the plugin with a code from your Whatching account, and shopper details are only sent while cart reminders are turned on in Whatching.

When cart reminders are on, the plugin sends to Whatching (api.whatching.com), for each checkout where a phone number is entered: the phone number, country, first name, the names and quantities of the items in the cart, the cart total and currency, and a random cart code. When an order is placed, it sends the order number and total. It never sends addresses or email addresses. The cart's products themselves stay in your WordPress site for 7 days so the reminder link can refill the cart. While connected, the plugin also checks with Whatching every 15 minutes whether reminders are on, sending only the plugin's version.

* Whatching terms of service: https://www.whatching.com/terms
* Whatching privacy policy: https://www.whatching.com/privacy-policy

== Installation ==

1. Install and activate the plugin. WooCommerce must be active.
2. On Whatching, open your Store page (your WooCommerce store must already be connected there) and click "Connect plugin" to get a code.
3. In WordPress, go to WooCommerce → Whatching, paste the code and click Connect.
4. On the Whatching Store page, turn cart reminders on and choose the reminder messages.

== Frequently Asked Questions ==

= Do I need a Whatching account? =

Yes. The reminders are sent through your Whatching account and your WhatsApp Business number.

= Does it work with the checkout block? =

Yes, with both the block checkout and the classic checkout.

= What happens when I uninstall the plugin? =

The plugin deletes its settings and the saved carts from your site, and stops sending anything to Whatching.

== Changelog ==

= 1.0.1 =
* The plugin now checks with Whatching every 15 minutes, so turning reminders on or off takes effect without opening the plugin's page.

= 1.0.0 =
* First release: cart reminders on WhatsApp through Whatching.
